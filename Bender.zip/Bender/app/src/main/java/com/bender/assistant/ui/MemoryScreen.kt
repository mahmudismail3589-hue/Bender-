@file:OptIn(ExperimentalMaterial3Api::class)

package com.bender.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun MemoryScreen(vm: MainViewModel, memoryOn: Boolean, onBack: () -> Unit) {
    val items by vm.memories.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Memories") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
                actions = { if (items.isNotEmpty()) TextButton(onClick = { vm.clearMemories() }) { Text("Clear all") } },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp).navigationBarsPadding()) {
            if (!memoryOn) Text("Memory is turned off. Bender won't save anything new.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
            if (items.isEmpty()) Text("Nothing stored yet. Say “Remember that …” with memory turned on.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn {
                items(items, key = { it.id }) { m ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(m.text, Modifier.weight(1f))
                        IconButton(onClick = { vm.deleteMemory(m.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete memory") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
