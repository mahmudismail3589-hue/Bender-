package com.bender.assistant.ui

import android.app.Application
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bender.assistant.BenderApp
import com.bender.assistant.data.BenderSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val a = application as BenderApp
    val engine get() = a.engine

    val ui = a.engine.state
    /** null until DataStore has loaded (avoids flashing onboarding). */
    val settings: StateFlow<BenderSettings?> = a.settingsRepo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val messages = a.db.messageDao().all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val memories = a.db.memoryDao().all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun <T> set(key: Preferences.Key<T>, value: T) { viewModelScope.launch { a.settingsRepo.set(key, value) } }
    fun token(): String? = a.secure.token()
    fun saveToken(v: String) = a.secure.setToken(v)
    fun clearHistory() { viewModelScope.launch { a.db.messageDao().clear() } }
    fun clearMemories() { viewModelScope.launch { a.db.memoryDao().clear() } }
    fun deleteMemory(id: Long) { viewModelScope.launch { a.db.memoryDao().delete(id) } }
}
