package com.bender.assistant.engine

import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.bender.assistant.BenderApp
import com.bender.assistant.ai.AiException
import com.bender.assistant.ai.Brain
import com.bender.assistant.ai.BrainReply
import com.bender.assistant.commands.ActionExecutor
import com.bender.assistant.commands.BenderAction
import com.bender.assistant.commands.LocalCommands
import com.bender.assistant.data.BenderSettings
import com.bender.assistant.data.MemoryEntity
import com.bender.assistant.data.MessageEntity
import com.bender.assistant.voice.SpeechInput
import com.bender.assistant.voice.Tts
import com.bender.assistant.voice.WakeWordDetector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext

enum class Phase { Idle, Listening, Thinking, Speaking }

data class UiState(
    val phase: Phase = Phase.Idle,
    val partial: String = "",
    val error: String? = null,
    val notice: String? = null,
    val pendingConfirm: String? = null,
)

/**
 * The single brain of the app: listen -> think -> act -> speak. Shared by the UI (via MainViewModel) and by
 * BenderService, so foreground and background behave identically.
 */
class AssistantEngine(private val app: BenderApp) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val speech by lazy { SpeechInput(app) }
    val tts by lazy { Tts(app) }
    private val brain by lazy { Brain(app) }
    private val executor by lazy { ActionExecutor(app) }

    val state = MutableStateFlow(UiState())
    /** Permission the UI should ask for (activity collects this). */
    val permissionRequests = MutableSharedFlow<String>(extraBufferCapacity = 4)

    private var turn: Job? = null
    private var wake: WakeWordDetector? = null
    private var wakePhrase = "hey bender"
    private var pending: BenderAction? = null
    private var ttsNoticeShown = false

    // ---------- wake word (called by BenderService) ----------
    fun attachWake(phrase: String) {
        wakePhrase = phrase
        val w = wake ?: WakeWordDetector(speech, scope) { remainder -> beginTurn(remainder) }.also { wake = it }
        if (turn?.isActive != true) w.start(phrase)
    }

    fun detachWake() {
        val w = wake ?: return
        wake = null
        scope.launch { w.stopAndJoin() }
    }

    // ---------- public controls ----------
    /** Start a conversation turn. [initial] = already-known text (typed, or the command spoken after the wake phrase). */
    fun beginTurn(initial: String? = null, typed: Boolean = false) {
        turn?.cancel()
        pending = null
        val job = scope.launch(start = CoroutineStart.LAZY) {
            val me = coroutineContext[Job]
            try {
                wake?.stopAndJoin()          // the mic is needed for this turn
                tts.stop()
                state.update { it.copy(error = null, notice = null, pendingConfirm = null) }
                runTurns(initial, typed)
            } finally {
                state.update { it.copy(phase = Phase.Idle, partial = "") }
                if (turn === me) wake?.start(wakePhrase)
            }
        }
        turn = job
        job.start()
    }

    fun sendText(text: String) { if (text.isNotBlank()) beginTurn(text.trim(), typed = true) }

    fun interrupt() {
        turn?.cancel()
        tts.stop()
        state.update { it.copy(phase = Phase.Idle, partial = "") }
    }

    /** Orb tap: idle -> listen, listening/thinking -> stop, speaking -> interrupt and listen (barge-in). */
    fun onOrbTap() {
        when (state.value.phase) {
            Phase.Idle -> beginTurn()
            Phase.Speaking -> { interrupt(); beginTurn() }
            else -> interrupt()
        }
    }

    fun confirm() {
        val a = pending ?: return
        pending = null
        state.update { it.copy(pendingConfirm = null) }
        scope.launch {
            val out = StringBuilder()
            runAction(a, out, confirmed = true)
            val s = app.settingsRepo.now()
            if (out.isNotBlank()) speak(out.toString().trim(), langTag(s, "en"), s)
            state.update { it.copy(phase = Phase.Idle) }
        }
    }

    fun cancelPending() { pending = null; state.update { it.copy(pendingConfirm = null) } }
    fun dismissMessages() = state.update { it.copy(error = null, notice = null) }

    // ---------- turn pipeline ----------
    private suspend fun runTurns(initial: String?, typed: Boolean) {
        var text = initial?.takeIf { it.isNotBlank() }
        var followUp = false
        while (true) {
            val s = app.settingsRepo.now()
            val input = text ?: listen(s, followUp) ?: return
            text = null
            val again = process(input, s)
            if (typed || !again || !s.continuous) return
            followUp = true
        }
    }

    private suspend fun listen(s: BenderSettings, followUp: Boolean): String? {
        if (!hasMic()) { permissionRequests.tryEmit(Manifest.permission.RECORD_AUDIO); fail("I need microphone permission to listen."); return null }
        if (!speech.available()) { fail("Speech recognition isn't available on this phone. Install or enable Google speech services."); return null }
        state.update { it.copy(phase = Phase.Listening, partial = "", error = null) }
        var result: String? = null
        speech.listen(sttTag(s)).collect { ev ->
            when (ev) {
                is SpeechInput.Event.Partial -> state.update { it.copy(partial = ev.text) }
                is SpeechInput.Event.Final -> result = ev.text
                is SpeechInput.Event.Error -> {
                    val quiet = followUp && (ev.code == 6 || ev.code == 7)
                    if (!quiet) fail(SpeechInput.errorText(ev.code))
                    if (ev.code == 9) permissionRequests.tryEmit(Manifest.permission.RECORD_AUDIO)
                }
            }
        }
        return result?.takeIf { it.isNotBlank() }
    }

    /** @return true if the conversation can continue hands-free. */
    private suspend fun process(text: String, s: BenderSettings): Boolean {
        val dao = app.db.messageDao()
        dao.insert(MessageEntity(role = "user", text = text))
        state.update { it.copy(phase = Phase.Thinking, partial = text, error = null) }

        var ok = true
        val result: BrainReply = LocalCommands.parse(text) ?: try {
            brain.ask(s)
        } catch (e: AiException) {
            ok = false
            BrainReply(friendly(e), "en", emptyList())
        }
        if (result.reply.isNotBlank()) dao.insert(MessageEntity(role = "assistant", text = result.reply))

        val spoken = StringBuilder(result.reply)
        for (a in result.actions) {
            if (s.confirmActions && a is BenderAction.Call && app.uiVisible) {
                pending = a
                val msg = "Call ${a.target}?"
                state.update { it.copy(pendingConfirm = msg) }
                spoken.append(" ").append(msg)
                ok = false
            } else runAction(a, spoken, confirmed = false)
        }
        speak(spoken.toString().trim(), langTag(s, result.lang), s)
        return ok
    }

    private suspend fun runAction(a: BenderAction, out: StringBuilder, confirmed: Boolean) {
        if (a is BenderAction.Remember) {
            val s = app.settingsRepo.now()
            if (s.memoryOn) app.db.memoryDao().insert(MemoryEntity(text = a.text))
            else out.append(" Memory is turned off in settings, so I didn't save that.")
            return
        }
        val r = executor.execute(a, confirmed)
        r.message?.let { out.append(" ").append(it) }
        r.needsPermission?.let { permissionRequests.tryEmit(it) }
    }

    private suspend fun speak(text: String, tag: String, s: BenderSettings) {
        if (text.isBlank()) return
        state.update { it.copy(phase = Phase.Speaking) }
        when (tts.speak(text, tag, s.speechRate, s.voiceName)) {
            Tts.Result.Failed -> state.update { it.copy(error = "I couldn't speak that out loud. Check your text-to-speech engine in Android settings.") }
            Tts.Result.Fallback -> if (!ttsNoticeShown) {
                ttsNoticeShown = true
                state.update { it.copy(notice = "No voice is installed for this language, so I'm using a default voice.") }
            }
            Tts.Result.Spoken -> {}
        }
    }

    // ---------- helpers ----------
    private fun fail(msg: String) = state.update { it.copy(phase = Phase.Idle, error = msg) }
    private fun hasMic() = ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun sttTag(s: BenderSettings): String? = when (s.language) { "en" -> "en-US"; "ha" -> "ha-NG"; else -> null }
    private fun langTag(s: BenderSettings, replyLang: String) = when (s.language) {
        "en" -> "en-US"; "ha" -> "ha-NG"; else -> if (replyLang == "ha") "ha-NG" else "en-US"
    }

    private fun friendly(e: AiException) = when (e.kind) {
        AiException.Kind.NOT_CONFIGURED -> "I can do basic commands offline, but my AI brain isn't set up yet. Add your backend address in Settings."
        AiException.Kind.OFFLINE -> "I can't reach the internet right now. Basic commands still work offline."
        AiException.Kind.SERVER -> "My AI service had a problem (${e.message}). Please try again in a moment."
        AiException.Kind.BAD_RESPONSE -> "I got an answer I couldn't understand. Please try again."
    }
}
