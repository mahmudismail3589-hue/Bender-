@file:OptIn(ExperimentalMaterial3Api::class)

package com.bender.assistant.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.bender.assistant.data.BenderSettings
import com.bender.assistant.data.Keys

fun isGranted(ctx: Context, perm: String?): Boolean = when {
    perm == null -> NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    perm == Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33 -> true
    else -> ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
}

private data class PermRow(val label: String, val why: String, val perm: String?)

@Composable
fun SettingsScreen(vm: MainViewModel, s: BenderSettings, onBack: () -> Unit, onMemory: () -> Unit, onRequestPerm: (String) -> Unit) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }

    // Refresh permission status whenever we come back from a system dialog / settings page.
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    @Suppress("UNUSED_VARIABLE") val refresh = tick

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp).verticalScroll(rememberScrollState()).navigationBarsPadding()) {

            SectionTitle("Voice")
            SwitchRow("Wake word", "Say “${s.wakePhrase}” to talk. Uses the microphone while Bender is running; see About for limits.", s.wakeWord) { vm.set(Keys.WAKE, it) }
            TextSetting("Wake phrase", s.wakePhrase) { vm.set(Keys.PHRASE, it.trim().lowercase().ifBlank { "hey bender" }) }
            Text("Voice language", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
            ChipsRow(listOf("auto" to "Auto-detect", "en" to "English", "ha" to "Hausa"), s.language) { vm.set(Keys.LANG, it) }

            var voices by remember { mutableStateOf(listOf<String>()) }
            LaunchedEffect(s.language) { voices = vm.engine.tts.voiceNames(if (s.language == "ha") "ha-NG" else "en-US") }
            var menu by remember { mutableStateOf(false) }
            Box(Modifier.padding(top = 8.dp)) {
                OutlinedButton(onClick = { menu = true }) { Text("Assistant voice: " + s.voiceName.ifBlank { "Default" }) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Default") }, onClick = { vm.set(Keys.VOICE, ""); menu = false })
                    voices.forEach { v -> DropdownMenuItem(text = { Text(v) }, onClick = { vm.set(Keys.VOICE, v); menu = false }) }
                }
            }
            Text("Speech speed: ${"%.1f".format(s.speechRate)}x", Modifier.padding(top = 8.dp))
            Slider(value = s.speechRate, onValueChange = { vm.set(Keys.RATE, it) }, valueRange = 0.5f..2f)
            SwitchRow("Continuous conversation", "After Bender answers, listen again without tapping.", s.continuous) { vm.set(Keys.CONTINUOUS, it) }
            SwitchRow("Confirm sensitive actions", "Ask before starting a phone call.", s.confirmActions) { vm.set(Keys.CONFIRM, it) }

            SectionTitle("AI model / API")
            Text("Bender talks to YOUR proxy server, never directly to an AI provider, so no API key is stored in the app. See README.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            TextSetting("Backend URL (https://…)", s.backendUrl) { vm.set(Keys.BACKEND, it.trim()) }
            var token by remember { mutableStateOf(vm.token().orEmpty()) }
            TextSetting("Access token for your proxy", token, secret = true) { vm.saveToken(it); token = it }
            TextSetting("Model name (optional)", s.model) { vm.set(Keys.MODEL, it.trim()) }

            SectionTitle("Background assistant")
            SwitchRow("Background assistant", "Keeps a visible notification with Talk / Pause / Stop. The microphone is used only if Wake word is also on.", s.backgroundOn) { vm.set(Keys.BACKGROUND, it) }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
            }) { Text("Notification settings") }

            SectionTitle("Memory")
            SwitchRow("Remember things", "When on, Bender may save facts you ask it to remember and use them in answers. Off by default.", s.memoryOn) { vm.set(Keys.MEMORY, it) }
            OutlinedButton(onClick = onMemory) { Text("View stored memories") }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { dialog = "Clear all conversation history?" to { vm.clearHistory() } }) { Text("Clear history") }
                OutlinedButton(onClick = { dialog = "Delete all memories?" to { vm.clearMemories() } }) { Text("Clear memory") }
            }

            SectionTitle("Permissions")
            val rows = listOf(
                PermRow("Microphone", "Hear your voice commands.", Manifest.permission.RECORD_AUDIO),
                PermRow("Notifications", "Show the background status and reminders.", Manifest.permission.POST_NOTIFICATIONS),
                PermRow("Contacts", "Find who to call or message by name.", Manifest.permission.READ_CONTACTS),
                PermRow("Phone calls", "Place a call directly after you confirm (otherwise the dialer opens).", Manifest.permission.CALL_PHONE),
                PermRow("Notification access", "Optional. Lets Bender read recent notifications aloud on request.", null),
            )
            rows.forEach { r ->
                val ok = isGranted(ctx, r.perm)
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(r.label, style = MaterialTheme.typography.bodyLarge)
                        Text(r.why, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (ok) Text("Granted", color = MaterialTheme.colorScheme.primary)
                    else TextButton(onClick = {
                        if (r.perm == null) ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) else onRequestPerm(r.perm)
                    }) { Text("Grant") }
                }
            }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Open app permission settings") }

            SectionTitle("Theme")
            ChipsRow(listOf("system" to "System", "light" to "Light", "dark" to "Dark"), s.theme) { vm.set(Keys.THEME, it) }

            SectionTitle("About Bender")
            Text(
                "Bender 1.0, a personal voice assistant for English and Hausa.\n\n" +
                    "What Android does not allow a normal app to do: always-on hotword detection like the built-in assistant " +
                    "(Bender uses a speech-recognizer loop while its service runs, which costs more battery and can be interrupted by the system); " +
                    "listening after reboot or a force-stop without you opening the app; opening other apps from the background " +
                    "(Bender posts a tap-to-run notification instead); sending SMS silently (it opens a pre-filled message); " +
                    "or acting on the lock screen. Hausa speech recognition and voices depend on what Google speech services installed on your phone support.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(32.dp))
        }
    }

    dialog?.let { (msg, action) ->
        AlertDialog(
            onDismissRequest = { dialog = null }, title = { Text("Are you sure?") }, text = { Text(msg) },
            confirmButton = { TextButton(onClick = { action(); dialog = null }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } },
        )
    }
}
