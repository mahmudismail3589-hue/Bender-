package com.bender.assistant.voice

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Wake phrase detection built ONLY on public Android APIs: a loop of short SpeechRecognizer sessions that looks for
 * the phrase in each result. Honest limitations (also in README): it is not a true low-power hotword engine, it uses more
 * battery than one, some devices play a start/stop sound per session, and it only runs while BenderService is running.
 * For production-grade always-on detection plug an offline engine (e.g. Picovoice Porcupine) in here.
 */
class WakeWordDetector(
    private val speech: SpeechInput,
    private val scope: CoroutineScope,
    private val onWake: (remainder: String?) -> Unit,
) {
    private var job: Job? = null

    fun start(phrase: String) {
        if (job?.isActive == true) return
        val p = normalize(phrase)
        job = scope.launch {
            while (isActive) {
                var heard = false
                var err = 0
                speech.listen("en-US").collect { ev ->
                    when (ev) {
                        is SpeechInput.Event.Final -> match(ev.text, p)?.let { heard = true; onWake(it.ifBlank { null }) }
                        is SpeechInput.Event.Error -> err = ev.code
                        else -> {}
                    }
                }
                if (heard) return@launch
                when (err) {
                    9 -> return@launch            // permission lost: stop quietly
                    8 -> delay(1000)              // recognizer busy
                    0, 6, 7 -> delay(250)         // silence / no match: normal, loop again
                    else -> delay(2000)           // network/server/etc: back off to save battery
                }
            }
        }
    }

    suspend fun stopAndJoin() { job?.cancelAndJoin(); job = null }

    private fun normalize(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Returns the text after the wake phrase ("" if nothing follows), or null when the phrase wasn't heard. */
    private fun match(text: String, phrase: String): String? {
        val t = normalize(text)
        val idx = t.indexOf(phrase)
        if (idx >= 0) return t.substring(idx + phrase.length).trim()
        val last = Regex.escape(phrase.substringAfterLast(' '))
        val m = Regex("\\b(hey|hay|hi|ok|okay)\\s+$last\\b").find(t) ?: return null
        return t.substring(m.range.last + 1).trim()
    }
}
