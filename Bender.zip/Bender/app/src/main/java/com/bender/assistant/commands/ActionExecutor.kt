package com.bender.assistant.commands

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.bender.assistant.BenderApp
import com.bender.assistant.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ActionResult(val message: String? = null, val needsPermission: String? = null)

/**
 * Runs actions through official Android APIs only. Anything that would start another app's UI while Bender is in the
 * background is turned into a tap-to-run notification, because Android 10+ blocks background activity starts.
 */
class ActionExecutor(private val app: BenderApp) {

    suspend fun execute(a: BenderAction, confirmed: Boolean): ActionResult = try {
        run(a, confirmed)
    } catch (e: ActivityNotFoundException) {
        ActionResult("I couldn't find an app that can do that.")
    } catch (e: SecurityException) {
        ActionResult("Android blocked that action. Check Bender's permissions in Settings.")
    } catch (e: Exception) {
        ActionResult("Sorry, that action failed.")
    }

    private suspend fun run(a: BenderAction, confirmed: Boolean): ActionResult = when (a) {
        is BenderAction.OpenApp -> openApp(a.name)
        is BenderAction.OpenUrl -> {
            val u = if (a.url.contains("://")) a.url else "https://${a.url}"
            val uri = Uri.parse(u)
            if (uri.scheme != "http" && uri.scheme != "https") ActionResult("I can only open web links.")
            else launch(Intent(Intent.ACTION_VIEW, uri), "open the website")
        }
        is BenderAction.Call -> {
            val num = numberFor(a.target)
            when (num) {
                NEEDS_PERM -> ActionResult("I need permission to read your contacts first.", Manifest.permission.READ_CONTACTS)
                null -> ActionResult("I couldn't find ${a.target} in your contacts.")
                else -> {
                    val direct = confirmed && granted(Manifest.permission.CALL_PHONE)
                    launch(Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(num.orEmpty())}")), "call ${a.target}")
                }
            }
        }
        is BenderAction.Sms -> {
            val num = numberFor(a.target)
            when (num) {
                NEEDS_PERM -> ActionResult("I need permission to read your contacts first.", Manifest.permission.READ_CONTACTS)
                null -> ActionResult("I couldn't find ${a.target} in your contacts.")
                // Opens the SMS composer pre-filled; the user presses send, so no SEND_SMS permission is needed.
                else -> launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(num.orEmpty())}")).putExtra("sms_body", a.body), "send the message")
            }
        }
        is BenderAction.Alarm -> launch(
            Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.hour).putExtra(AlarmClock.EXTRA_MINUTES, a.minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.label.ifBlank { "Bender" }).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
            "set the alarm",
        )
        is BenderAction.Timer -> launch(
            Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, a.label).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
            "start the timer",
        )
        is BenderAction.Reminder -> reminder(a)
        is BenderAction.Navigate -> launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(a.query)}")), "start navigation")
        is BenderAction.WebSearch -> launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, a.query), "search the web")
        is BenderAction.Flashlight -> flashlight(a.on)
        is BenderAction.Volume -> volume(a.mode)
        is BenderAction.Media -> media(a.cmd)
        is BenderAction.OpenSettings -> launch(Intent(settingsAction(a.page)), "open settings")
        is BenderAction.CalendarEvent -> launch(
            Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, a.title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, a.startMillis).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, a.endMillis),
            "add the calendar event",
        )
        is BenderAction.Share -> launch(
            Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.text), "Share"), "share",
        )
        is BenderAction.Copy -> {
            app.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Bender", a.text))
            ActionResult("Copied.")
        }
        is BenderAction.ReadNotifications -> readNotifications()
        is BenderAction.Remember -> ActionResult() // handled by the engine (needs the memory setting)
    }

    // ---- helpers ----
    private fun granted(p: String) = ContextCompat.checkSelfPermission(app, p) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun launch(i: Intent, label: String): ActionResult {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (app.uiVisible) { app.startActivity(i); return ActionResult() }
        val pi = PendingIntent.getActivity(app, label.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(app, BenderApp.CH_ACTIONS)
            .setSmallIcon(R.drawable.ic_bender).setContentTitle("Bender").setContentText("Tap to $label")
            .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        val nm = NotificationManagerCompat.from(app)
        if (!nm.areNotificationsEnabled()) return ActionResult("Android doesn't let me do that from the background. Open Bender and ask again.")
        nm.notify(label.hashCode(), n)
        return ActionResult("Tap the notification to $label.")
    }

    private fun openApp(name: String): ActionResult {
        val pm = app.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.lowercase().trim()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { val l = it.loadLabel(pm).toString().lowercase(); l.contains(q) || q.contains(l) }
            ?: return ActionResult("I couldn't find an app called $name.")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return ActionResult("I can't open $name.")
        return launch(intent, "open $name")
    }

    private suspend fun numberFor(target: String): String? {
        val digits = target.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 5) return digits
        if (!granted(Manifest.permission.READ_CONTACTS)) return NEEDS_PERM
        return withContext(Dispatchers.IO) {
            app.contentResolver.query(
                Phone.CONTENT_URI, arrayOf(Phone.NUMBER), "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$target%"), "${Phone.DISPLAY_NAME} ASC",
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        }
    }

    private fun reminder(a: BenderAction.Reminder): ActionResult {
        if (a.atMillis <= System.currentTimeMillis()) return ActionResult("That time has already passed.")
        val am = app.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            app, (a.atMillis / 1000).toInt(), Intent(app, ReminderReceiver::class.java).putExtra("text", a.text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, a.atMillis, pi) // inexact: no special exact-alarm permission needed
        return ActionResult()
    }

    private fun flashlight(on: Boolean): ActionResult {
        val cm = app.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return ActionResult("This phone has no flashlight.")
        cm.setTorchMode(id, on)
        return ActionResult()
    }

    private fun volume(mode: String): ActionResult {
        val am = app.getSystemService(AudioManager::class.java)
        val s = AudioManager.STREAM_MUSIC
        when (mode) {
            "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "max" -> am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
            else -> return ActionResult("I can turn the volume up, down, mute, or to max.")
        }
        return ActionResult()
    }

    private fun media(cmd: String): ActionResult {
        val code = when (cmd) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = app.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ActionResult()
    }

    private fun settingsAction(page: String) = when (page) {
        "wifi" -> Settings.ACTION_WIFI_SETTINGS
        "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
        "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
        "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        "sound" -> Settings.ACTION_SOUND_SETTINGS
        "display" -> Settings.ACTION_DISPLAY_SETTINGS
        "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
        "apps" -> Settings.ACTION_APPLICATION_SETTINGS
        else -> Settings.ACTION_SETTINGS
    }

    private fun readNotifications(): ActionResult {
        if (!NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName)) {
            val r = launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), "enable notification access")
            return ActionResult("I need notification access first. ${r.message.orEmpty()}".trim())
        }
        val items = BenderNotificationListener.snapshot().take(5)
        if (items.isEmpty()) return ActionResult("You have no recent notifications.")
        return ActionResult("You have ${items.size} recent. " + items.joinToString(". ") { "${it.app}: ${it.title} ${it.text}".trim() })
    }

    companion object { private const val NEEDS_PERM = "__needs_permission__" }
}
