package com.bender.assistant.commands

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Only active if the user explicitly grants Notification Access. Keeps the most recent notifications IN MEMORY ONLY
 * (never written to disk, never sent to the AI backend) so Bender can read them aloud on request.
 */
class BenderNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) { sbn.packageName }
        add(Item(sbn.key, label, title, text))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) = remove(sbn.key)
    override fun onListenerDisconnected() = clear()

    data class Item(val key: String, val app: String, val title: String, val text: String)

    companion object {
        private val items = ArrayDeque<Item>()
        @Synchronized private fun add(i: Item) { items.removeAll { it.key == i.key }; items.addFirst(i); while (items.size > 20) items.removeLast() }
        @Synchronized private fun remove(key: String) { items.removeAll { it.key == key } }
        @Synchronized private fun clear() = items.clear()
        @Synchronized fun snapshot(): List<Item> = items.toList()
    }
}
