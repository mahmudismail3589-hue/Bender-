package com.bender.assistant.commands

sealed interface BenderAction {
    data class OpenApp(val name: String) : BenderAction
    data class OpenUrl(val url: String) : BenderAction
    data class Call(val target: String) : BenderAction
    data class Sms(val target: String, val body: String) : BenderAction
    data class Alarm(val hour: Int, val minute: Int, val label: String) : BenderAction
    data class Timer(val seconds: Int, val label: String) : BenderAction
    data class Reminder(val atMillis: Long, val text: String) : BenderAction
    data class Navigate(val query: String) : BenderAction
    data class WebSearch(val query: String) : BenderAction
    data class Flashlight(val on: Boolean) : BenderAction
    data class Volume(val mode: String) : BenderAction
    data class Media(val cmd: String) : BenderAction
    data class OpenSettings(val page: String) : BenderAction
    data class CalendarEvent(val title: String, val startMillis: Long, val endMillis: Long) : BenderAction
    data class Share(val text: String) : BenderAction
    data class Copy(val text: String) : BenderAction
    data object ReadNotifications : BenderAction
    data class Remember(val text: String) : BenderAction
}

/** Converts the model's JSON actions into typed actions. Unknown/invalid actions are dropped. */
object ActionParser {
    private fun Map<String, Any?>.s(k: String): String = (this[k] as? String)?.trim().orEmpty()
    private fun Map<String, Any?>.n(k: String): Double = when (val v = this[k]) {
        is Number -> v.toDouble(); is String -> v.toDoubleOrNull() ?: 0.0; else -> 0.0
    }
    private fun Map<String, Any?>.b(k: String): Boolean = when (val v = this[k]) {
        is Boolean -> v; is String -> v.equals("true", true); else -> false
    }

    fun parse(type: String, a: Map<String, Any?>): BenderAction? = when (type.trim().lowercase()) {
        "open_app" -> a.s("name").ifBlank { null }?.let { BenderAction.OpenApp(it) }
        "open_url" -> a.s("url").ifBlank { null }?.let { BenderAction.OpenUrl(it) }
        "call" -> a.s("target").ifBlank { null }?.let { BenderAction.Call(it) }
        "sms" -> a.s("target").ifBlank { null }?.let { BenderAction.Sms(it, a.s("body")) }
        "alarm" -> BenderAction.Alarm(a.n("hour").toInt().coerceIn(0, 23), a.n("minute").toInt().coerceIn(0, 59), a.s("label"))
        "timer" -> a.n("seconds").toInt().takeIf { it > 0 }?.let { BenderAction.Timer(it, a.s("label")) }
        "reminder" -> a.n("atMillis").toLong().takeIf { it > 0 }?.let { BenderAction.Reminder(it, a.s("text").ifBlank { "Reminder" }) }
        "navigate" -> a.s("query").ifBlank { null }?.let { BenderAction.Navigate(it) }
        "search" -> a.s("query").ifBlank { null }?.let { BenderAction.WebSearch(it) }
        "flashlight" -> BenderAction.Flashlight(a.b("on"))
        "volume" -> BenderAction.Volume(a.s("mode").lowercase())
        "media" -> BenderAction.Media(a.s("cmd").lowercase())
        "settings" -> BenderAction.OpenSettings(a.s("page").lowercase())
        "calendar" -> a.n("startMillis").toLong().takeIf { it > 0 }?.let {
            val end = a.n("endMillis").toLong().takeIf { e -> e > it } ?: (it + 3_600_000L)
            BenderAction.CalendarEvent(a.s("title").ifBlank { "Event" }, it, end)
        }
        "share" -> a.s("text").ifBlank { null }?.let { BenderAction.Share(it) }
        "copy" -> a.s("text").ifBlank { null }?.let { BenderAction.Copy(it) }
        "read_notifications" -> BenderAction.ReadNotifications
        "remember" -> a.s("text").ifBlank { null }?.let { BenderAction.Remember(it) }
        else -> null
    }
}
