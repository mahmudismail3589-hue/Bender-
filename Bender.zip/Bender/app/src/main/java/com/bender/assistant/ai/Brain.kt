package com.bender.assistant.ai

import com.bender.assistant.BenderApp
import com.bender.assistant.commands.ActionParser
import com.bender.assistant.commands.BenderAction
import com.bender.assistant.data.BenderSettings
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class BrainReply(val reply: String, val lang: String, val actions: List<BenderAction>)

class AiException(val kind: Kind, message: String? = null) : Exception(message) {
    enum class Kind { NOT_CONFIGURED, OFFLINE, SERVER, BAD_RESPONSE }
}

private data class RawAction(val type: String?, val args: Map<String, Any?>?)
private data class RawReply(val reply: String?, val lang: String?, val actions: List<RawAction>?)

/** Talks to the proxy; asks the model for a strict JSON { reply, lang, actions[] } so replies can trigger phone actions. */
class Brain(private val app: BenderApp) {
    private val gson = Gson()

    suspend fun ask(s: BenderSettings): BrainReply {
        val base = s.backendUrl.trim()
        if (base.isBlank() || base.contains("YOUR_PROXY_HOST")) throw AiException(AiException.Kind.NOT_CONFIGURED)

        val history = app.db.messageDao().last(12).reversed()
            .map { ChatMsg(if (it.role == "user") "user" else "assistant", it.text) }
        val memories = if (s.memoryOn) app.db.memoryDao().list().map { it.text } else emptyList()
        val req = ChatRequest(systemPrompt(s, memories), history, s.language, s.model.ifBlank { null })

        val resp = try {
            withContext(Dispatchers.IO) { ApiFactory.create(base, app.secure.token()).chat(req) }
        } catch (e: HttpException) {
            throw AiException(AiException.Kind.SERVER, "HTTP ${e.code()}")
        } catch (e: IOException) {
            throw AiException(AiException.Kind.OFFLINE)
        } catch (e: IllegalArgumentException) {
            throw AiException(AiException.Kind.NOT_CONFIGURED, "Invalid backend URL")
        }
        val raw = resp.reply?.trim().orEmpty()
        if (raw.isEmpty()) throw AiException(AiException.Kind.BAD_RESPONSE)
        return parse(raw)
    }

    private fun parse(text: String): BrainReply {
        val cleaned = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start >= 0 && end > start) {
            try {
                val raw = gson.fromJson(cleaned.substring(start, end + 1), RawReply::class.java)
                val reply = raw?.reply?.trim().orEmpty()
                val acts = raw?.actions.orEmpty().mapNotNull { ActionParser.parse(it.type.orEmpty(), it.args.orEmpty()) }
                if (reply.isNotEmpty() || acts.isNotEmpty()) return BrainReply(reply, raw?.lang ?: "en", acts)
            } catch (_: JsonSyntaxException) { /* fall through to plain text */ }
        }
        return BrainReply(text, "en", emptyList())
    }

    private fun systemPrompt(s: BenderSettings, memories: List<String>): String {
        val now = SimpleDateFormat("EEEE yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val zone = TimeZone.getDefault().id
        val langRule = when (s.language) {
            "en" -> "Always reply in English."
            "ha" -> "Always reply in Hausa (Harshen Hausa), natural and conversational."
            else -> "Reply in the language the user used (English or Hausa). Users may mix both."
        }
        val mem = if (memories.isEmpty()) "" else "\nUser-approved memories:\n" + memories.joinToString("\n") { "- $it" }
        return """
You are Bender, a friendly, intelligent, concise voice assistant on an Android phone. Slightly futuristic, helpful, respectful.
Your replies are spoken aloud: 1-3 short sentences unless asked for more. No markdown, no emojis, no lists.
Languages: English and Hausa. $langRule
You can answer questions, chat, summarize, translate, write, reason, and help with code (read code aloud sparingly; offer to copy it to the clipboard instead).
You have NO live data (weather, news, scores). For those, say so briefly and use the "search" action.
Current local time: $now ($zone). Compute absolute times as epoch milliseconds in this time zone.

Respond with ONLY one JSON object, no code fences:
{"reply": string, "lang": "en" or "ha", "actions": [{"type": string, "args": object}]}
Use "actions": [] when no phone action is needed. Available actions (type: args):
open_app: {name} | open_url: {url} | call: {target: contact name or number} | sms: {target, body}
alarm: {hour 0-23, minute, label} | timer: {seconds, label} | reminder: {atMillis, text}
navigate: {query} | search: {query} | flashlight: {on: true/false}
volume: {mode: up|down|mute|max} | media: {cmd: play|pause|toggle|next|previous}
settings: {page: wifi|bluetooth|airplane|location|sound|display|battery|apps|main}
calendar: {title, startMillis, endMillis} | share: {text} | copy: {text}
read_notifications: {} | remember: {text}

Rules: never invent contacts or phone numbers. For translations, put the translated text in "reply" (and add a "copy" action if asked).
Use "remember" only when the user clearly asks you to remember something. Do not claim an action succeeded; the phone performs it.
If asked for something unsupported, say so briefly.$mem
""".trimIndent()
    }
}
