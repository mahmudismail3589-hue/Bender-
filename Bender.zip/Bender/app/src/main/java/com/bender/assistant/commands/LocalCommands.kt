package com.bender.assistant.commands

import com.bender.assistant.ai.BrainReply
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Fast, offline rules for the most common English + Hausa commands. They run before the AI call (instant, no network,
 * no tokens) and keep Bender useful with no internet. Everything else goes to the AI brain, which handles natural variations.
 */
object LocalCommands {
    private val haNums = mapOf(
        "daya" to 1, "biyu" to 2, "uku" to 3, "hudu" to 4, "biyar" to 5, "shida" to 6, "bakwai" to 7,
        "takwas" to 8, "tara" to 9, "goma" to 10, "sha daya" to 11, "sha biyu" to 12,
    )

    private fun norm(s: String) = s.lowercase().replace('ɗ', 'd').replace('ƙ', 'k').replace('ɓ', 'b').replace('’', '\'')
        .trim().trimEnd('.', '!', '?', ',').replace(Regex("^(hey|ok|okay) bender,? ?"), "").trim()

    private fun reply(en: String, ha: String, isHa: Boolean, vararg a: BenderAction) =
        BrainReply(if (isHa) ha else en, if (isHa) "ha" else "en", a.toList())

    fun parse(raw: String): BrainReply? {
        val t = norm(raw)

        Regex("^(?:please )?(?:turn|switch) (on|off) (?:the )?(?:flashlight|torch)$").find(t)?.let {
            val on = it.groupValues[1] == "on"
            return reply(if (on) "Flashlight on." else "Flashlight off.", "", false, BenderAction.Flashlight(on))
        }
        Regex("^(kunna|kashe) (?:the )?(?:flashlight|fitila|torch)$").find(t)?.let {
            val on = it.groupValues[1] == "kunna"
            return reply("", if (on) "Na kunna fitila." else "Na kashe fitila.", true, BenderAction.Flashlight(on))
        }
        Regex("^(?:what(?:'s| is) the time|what time is it(?: now)?|tell me the time)$").find(t)?.let {
            return reply("It's ${timeNow()}.", "", false)
        }
        Regex("^(?:karfe nawa(?: ne)?(?: yanzu)?|menene lokaci)$").find(t)?.let {
            return reply("", "Yanzu karfe ${timeNow()}.", true)
        }
        Regex("^(?:please )?(?:open|launch|start) (?:the )?([^.]+?)(?: app)?$").find(t)?.let {
            val n = it.groupValues[1]
            if (!n.contains("http") && !n.startsWith("a ") && n.length < 40) return reply("Opening $n.", "", false, BenderAction.OpenApp(n))
        }
        Regex("^bude (?:manhajar )?(.+)$").find(t)?.let {
            return reply("", "Ina buɗe ${it.groupValues[1]}.", true, BenderAction.OpenApp(it.groupValues[1]))
        }
        Regex("^(?:please )?(?:call|phone|dial|ring) (?!me\\b)(.+)$").find(t)?.let {
            return reply("Calling ${it.groupValues[1]}.", "", false, BenderAction.Call(it.groupValues[1]))
        }
        Regex("^kira (.+)$").find(t)?.let {
            return reply("", "Ina kiran ${it.groupValues[1]}.", true, BenderAction.Call(it.groupValues[1]))
        }
        if (t.contains("alarm") && Regex("^(?:please )?(?:set|create|make)\\b").containsMatchIn(t)) {
            Regex("alarm (?:for|at) (\\d{1,2})(?::(\\d{2}))? ?(am|pm)?").find(t)?.let {
                var h = it.groupValues[1].toInt()
                val m = it.groupValues[2].ifBlank { "0" }.toInt()
                when (it.groupValues[3]) {
                    "pm" -> if (h < 12) h += 12
                    "am" -> if (h == 12) h = 0
                }
                if (h in 0..23 && m in 0..59) return reply("Alarm set for ${"%d:%02d".format(h, m)}.", "", false, BenderAction.Alarm(h, m, "Bender"))
            }
        }
        Regex("^saita (?:min )?alarm karfe ((?:sha )?[a-z]+|\\d{1,2})(?::(\\d{2}))?( da rabi)?(?: na (safe|rana|yamma|dare))?$").find(t)?.let {
            var h = it.groupValues[1].toIntOrNull() ?: haNums[it.groupValues[1]] ?: return null
            val m = if (it.groupValues[3].isNotBlank()) 30 else it.groupValues[2].ifBlank { "0" }.toInt()
            when (it.groupValues[4]) {
                "rana", "yamma" -> if (h < 12) h += 12
                "dare" -> if (h in 6..11) h += 12 else if (h == 12) h = 0
                "safe" -> if (h == 12) h = 0
            }
            if (h in 0..23) return reply("", "Na saita alarm karfe ${"%d:%02d".format(h, m)}.", true, BenderAction.Alarm(h, m, "Bender"))
        }
        return null
    }

    private fun timeNow() = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
}
