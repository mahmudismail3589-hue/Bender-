package com.bender.assistant.ai

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

/**
 * Contract with YOUR proxy server (see /proxy). The Android app never talks to an AI provider directly,
 * so no provider API key ships inside the APK.
 */
data class ChatMsg(val role: String, val content: String)
data class ChatRequest(val system: String, val messages: List<ChatMsg>, val language: String, val model: String?)
data class ChatResponse(val reply: String?)

interface AiApi {
    @POST("chat") suspend fun chat(@Body request: ChatRequest): ChatResponse
}

object ApiFactory {
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(40, TimeUnit.SECONDS)
            .build()
    }
    private var cacheKey: String? = null
    private var cached: AiApi? = null

    @Synchronized
    fun create(baseUrl: String, token: String?): AiApi {
        val url = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        val key = "$url|$token"
        if (key == cacheKey) cached?.let { return it }
        val c = client.newBuilder().addInterceptor { chain ->
            val b = chain.request().newBuilder()
            if (!token.isNullOrBlank()) b.header("Authorization", "Bearer $token")
            chain.proceed(b.build())
        }.build()
        val api = Retrofit.Builder().baseUrl(url).client(c)
            .addConverterFactory(GsonConverterFactory.create())
            .build().create(AiApi::class.java)
        cacheKey = key; cached = api
        return api
    }
}
