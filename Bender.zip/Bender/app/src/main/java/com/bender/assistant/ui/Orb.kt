package com.bender.assistant.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.bender.assistant.engine.Phase
import kotlin.math.PI
import kotlin.math.sin

/** Animated Bender orb. Idle = slow glow, Listening = fast pulse, Thinking = spinning violet rings, Speaking = live waveform. */
@Composable
fun BenderOrb(phase: Phase, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(if (phase == Phase.Listening) 700 else 2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (phase == Phase.Thinking) 1100 else 7000, easing = LinearEasing)), label = "spin")
    val wave by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "wave")
    val c1 by animateColorAsState(if (phase == Phase.Thinking) cs.secondary else cs.primary, tween(500), label = "c1")
    val c2 by animateColorAsState(if (phase == Phase.Speaking) cs.secondary else cs.primary.copy(alpha = 0.6f), tween(500), label = "c2")
    val intensity by animateFloatAsState(if (phase == Phase.Idle) 0.55f else 1f, tween(500), label = "intensity")

    Canvas(
        modifier.aspectRatio(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
    ) {
        val c = center
        val base = size.minDimension / 2f
        val r = base * 0.55f * (1f + (if (phase == Phase.Listening) 0.12f else 0.04f) * pulse)

        drawCircle(Brush.radialGradient(listOf(c1.copy(alpha = 0.45f * intensity), Color.Transparent), center = c, radius = base), radius = base, center = c)
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), c1, c2.copy(alpha = 0.9f)), center = c - Offset(r * 0.25f, r * 0.25f), radius = r * 1.4f),
            radius = r, center = c,
        )
        rotate(spin, pivot = c) {
            drawCircle(Brush.sweepGradient(listOf(c1, Color.Transparent, c2, Color.Transparent, c1), center = c), radius = r * 1.35f, center = c, style = Stroke(3.dp.toPx()))
        }
        rotate(-spin * 0.6f, pivot = c) {
            drawCircle(Brush.sweepGradient(listOf(c2, Color.Transparent, c1, Color.Transparent, c2), center = c), radius = r * 1.6f, center = c, alpha = 0.6f, style = Stroke(2.dp.toPx()))
        }
        if (phase == Phase.Speaking) {
            val path = Path()
            val w = size.width * 0.5f
            val x0 = c.x - w / 2f
            for (i in 0..60) {
                val x = x0 + w * i / 60f
                val env = sin(PI * i / 60.0).toFloat()
                val y = c.y + sin(wave + i * 0.35f) * r * 0.28f * env
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, Color(0xFF05070F).copy(alpha = 0.85f), style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}
