package com.bender.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bender.assistant.data.Keys
import com.bender.assistant.service.BenderService
import com.bender.assistant.service.BenderSync
import com.bender.assistant.ui.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val app get() = application as BenderApp
    private lateinit var permLauncher: ActivityResultLauncher<String>
    private var lastRequested: String? = null
    private var talkAfterMic = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted && lastRequested == Manifest.permission.RECORD_AUDIO) {
                lifecycleScope.launch { BenderSync.apply(this@MainActivity, app.settingsRepo.now()) }
                if (talkAfterMic) app.engine.beginTurn()
            }
            talkAfterMic = false
        }
        if (savedInstanceState == null) handleIntent(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) { app.engine.permissionRequests.collect { request(it) } }
        }

        setContent {
            val vm: MainViewModel = viewModel()
            val loaded by vm.settings.collectAsStateWithLifecycle()
            val s = loaded ?: return@setContent
            val dark = when (s.theme) { "light" -> false; "dark" -> true; else -> isSystemInDarkTheme() }
            BenderTheme(dark) {
                var screen by rememberSaveable { mutableStateOf(if (s.onboarded) "main" else "onboarding") }
                LaunchedEffect(s.wakeWord, s.backgroundOn, s.wakePhrase) { BenderSync.apply(this@MainActivity, s) }
                BackHandler(enabled = screen == "settings" || screen == "memory") { screen = if (screen == "memory") "settings" else "main" }
                when (screen) {
                    "onboarding" -> OnboardingScreen(vm, ::request) { vm.set(Keys.ONBOARDED, true); screen = "main" }
                    "settings" -> SettingsScreen(vm, s, onBack = { screen = "main" }, onMemory = { screen = "memory" }, onRequestPerm = ::request)
                    "memory" -> MemoryScreen(vm, s.memoryOn) { screen = "settings" }
                    else -> MainScreen(vm) { screen = "settings" }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        app.uiVisible = true
        lifecycleScope.launch { BenderSync.apply(this@MainActivity, app.settingsRepo.now()) }
    }

    override fun onStop() {
        app.uiVisible = false
        // Wake-word-only mode (background assistant OFF) listens just while the app is visible.
        lifecycleScope.launch { if (!app.settingsRepo.now().backgroundOn) BenderService.stop(this@MainActivity) }
        super.onStop()
    }

    private fun handleIntent(i: Intent?) {
        val talk = i?.action == Intent.ACTION_ASSIST || i?.action == Intent.ACTION_VOICE_COMMAND || i?.getBooleanExtra(EXTRA_TALK, false) == true
        if (!talk) return
        i?.removeExtra(EXTRA_TALK)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) app.engine.beginTurn()
        else { talkAfterMic = true; request(Manifest.permission.RECORD_AUDIO) }
    }

    private fun request(perm: String) {
        lastRequested = perm
        permLauncher.launch(perm)
    }

    companion object { const val EXTRA_TALK = "bender_talk" }
}
