package com.bender.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.room.Room
import com.bender.assistant.data.BenderDb
import com.bender.assistant.data.SecureStore
import com.bender.assistant.data.SettingsRepo
import com.bender.assistant.engine.AssistantEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Application object = tiny service locator. Everything heavy is lazy for fast startup. */
class BenderApp : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settingsRepo by lazy { SettingsRepo(this) }
    val secure by lazy { SecureStore(this) }
    val db by lazy { Room.databaseBuilder(this, BenderDb::class.java, "bender.db").build() }
    val engine by lazy { AssistantEngine(this) }

    /** True while MainActivity is started (visible). Background starts of other apps' activities are blocked by Android 10+. */
    @Volatile var uiVisible = false

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Background assistant", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ACTIONS, "Assistant actions", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Reminders", NotificationManager.IMPORTANCE_HIGH))
    }

    companion object {
        const val CH_SERVICE = "bender_service"
        const val CH_ACTIONS = "bender_actions"
        const val CH_REMINDERS = "bender_reminders"
    }
}
