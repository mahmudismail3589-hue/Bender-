package com.bender.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bender.assistant.engine.Phase

@Composable
fun MainScreen(vm: MainViewModel, onSettings: () -> Unit) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val msgs by vm.messages.collectAsStateWithLifecycle()
    var typing by rememberSaveable { mutableStateOf(false) }
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Bender", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        }

        BenderOrb(ui.phase, Modifier.align(Alignment.CenterHorizontally).fillMaxWidth(0.5f).widthIn(max = 220.dp)) { vm.engine.onOrbTap() }

        Text(
            when (ui.phase) {
                Phase.Idle -> "Tap the orb or say “Hey Bender”"
                Phase.Listening -> "Listening…"
                Phase.Thinking -> "Thinking…"
                Phase.Speaking -> "Speaking… tap to interrupt"
            },
            Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
        )
        Text(
            ui.partial, Modifier.fillMaxWidth().heightIn(min = 24.dp).padding(horizontal = 8.dp, vertical = 4.dp), textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2,
        )

        (ui.error ?: ui.notice)?.let { msg ->
            Card(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = if (ui.error != null) MaterialTheme.colorScheme.error.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(msg, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
                    TextButton(onClick = { vm.engine.dismissMessages() }) { Text("OK") }
                }
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(msgs, key = { it.id }) { m ->
                val user = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.widthIn(max = 320.dp),
                    ) {
                        Text(
                            m.text, Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyMedium,
                            color = if (user) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconButton(onClick = { typing = !typing }) { Icon(Icons.Filled.Keyboard, contentDescription = "Keyboard input", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (typing) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), singleLine = true,
                    placeholder = { Text("Type to Bender") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { vm.engine.sendText(input); input = "" }),
                    trailingIcon = { IconButton(onClick = { vm.engine.sendText(input); input = "" }) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") } },
                )
            } else Spacer(Modifier.weight(1f))
            FilledIconButton(onClick = { vm.engine.onOrbTap() }, modifier = Modifier.size(64.dp)) {
                Icon(if (ui.phase == Phase.Idle) Icons.Filled.Mic else Icons.Filled.Stop, contentDescription = if (ui.phase == Phase.Idle) "Talk" else "Stop", modifier = Modifier.size(30.dp))
            }
        }
    }

    ui.pendingConfirm?.let { q ->
        AlertDialog(
            onDismissRequest = { vm.engine.cancelPending() },
            title = { Text("Please confirm") }, text = { Text(q) },
            confirmButton = { TextButton(onClick = { vm.engine.confirm() }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { vm.engine.cancelPending() }) { Text("Cancel") } },
        )
    }
}
