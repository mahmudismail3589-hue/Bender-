package com.bender.assistant.service

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.bender.assistant.BenderApp
import com.bender.assistant.MainActivity
import com.bender.assistant.R
import com.bender.assistant.data.BenderSettings
import com.bender.assistant.data.Keys
import kotlinx.coroutines.launch

/**
 * Microphone-type foreground service. It ONLY holds the microphone when wake word is enabled; otherwise it just keeps a
 * visible notification with "Talk / Pause / Stop" shortcuts. The notification is always shown (no hidden activity).
 * Android 14+ requires this service to be started while the app is visible; it is NOT restarted after reboot or process kill.
 */
class BenderService : Service() {
    private val app get() = application as BenderApp
    private var paused = false
    private var wakeOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Must call startForeground promptly after startForegroundService(), whatever the action is.
        if (!startFg()) { stopSelf(); return START_NOT_STICKY }
        when (intent?.action) {
            ACTION_STOP -> {
                app.appScope.launch { app.settingsRepo.set(Keys.BACKGROUND, false) }
                app.engine.detachWake()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> paused = !paused
        }
        app.appScope.launch { applyWake() }
        return START_NOT_STICKY
    }

    private suspend fun applyWake() {
        val s: BenderSettings = app.settingsRepo.now()
        val wantWake = s.wakeWord && !paused && hasMic()
        wakeOn = wantWake
        if (wantWake) app.engine.attachWake(s.wakePhrase) else app.engine.detachWake()
        notifyUpdate()
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startFg(): Boolean = try {
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        true
    } catch (e: Exception) { // e.g. Android 12+ background start restriction, or missing mic permission on Android 14+
        false
    }

    private fun notifyUpdate() {
        getSystemService(android.app.NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val talk = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TALK, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        fun svc(code: Int, action: String) = PendingIntent.getService(
            this, code, Intent(this, BenderService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val text = when {
            paused -> "Paused. Not listening."
            wakeOn -> "Listening for your wake phrase"
            else -> "Ready. Tap Talk to speak."
        }
        return NotificationCompat.Builder(this, BenderApp.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_bender).setContentTitle("Bender").setContentText(text)
            .setContentIntent(talk).setOngoing(true).setOnlyAlertOnce(true).setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Talk to Bender", talk)
            .addAction(0, if (paused) "Resume" else "Pause Bender", svc(1, ACTION_PAUSE))
            .addAction(0, "Stop Bender", svc(2, ACTION_STOP))
            .build()
    }

    override fun onDestroy() {
        app.engine.detachWake()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 42
        const val ACTION_PAUSE = "com.bender.assistant.PAUSE"
        const val ACTION_STOP = "com.bender.assistant.STOP"

        fun start(ctx: Context) = ContextCompat.startForegroundService(ctx, Intent(ctx, BenderService::class.java))
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, BenderService::class.java)) }
    }
}

/** Decides whether the service should run: background assistant ON, or wake word ON (then only while the app is visible). */
object BenderSync {
    fun apply(ctx: Context, s: BenderSettings) {
        val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (mic && (s.backgroundOn || s.wakeWord)) BenderService.start(ctx) else BenderService.stop(ctx)
    }
}
