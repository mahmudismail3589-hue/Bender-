package com.bender.assistant.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,           // "user" | "assistant"
    val text: String,
    val ts: Long = System.currentTimeMillis(),
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val ts: Long = System.currentTimeMillis(),
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY id ASC") fun all(): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :n") suspend fun last(n: Int): List<MessageEntity>
    @Insert suspend fun insert(m: MessageEntity)
    @Query("DELETE FROM messages") suspend fun clear()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY id DESC") fun all(): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memories ORDER BY id DESC") suspend fun list(): List<MemoryEntity>
    @Insert suspend fun insert(m: MemoryEntity)
    @Query("DELETE FROM memories WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM memories") suspend fun clear()
}

@Database(entities = [MessageEntity::class, MemoryEntity::class], version = 1, exportSchema = false)
abstract class BenderDb : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
}
