package com.bender.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF4DE1FF), onPrimary = Color(0xFF00252E), secondary = Color(0xFF9B7BFF),
    background = Color(0xFF05070F), surface = Color(0xFF0D1220), surfaceVariant = Color(0xFF1A2236),
    onBackground = Color(0xFFE6ECFF), onSurface = Color(0xFFE6ECFF), onSurfaceVariant = Color(0xFFA7B2D1),
    primaryContainer = Color(0xFF0B3A4A), onPrimaryContainer = Color(0xFFBFF3FF), error = Color(0xFFFF6B7A),
)
private val Light = lightColorScheme(
    primary = Color(0xFF006A85), onPrimary = Color.White, secondary = Color(0xFF6A4CD6),
    background = Color(0xFFF4F7FF), surface = Color.White, surfaceVariant = Color(0xFFE3E8F5),
    onBackground = Color(0xFF0B1020), onSurface = Color(0xFF0B1020), onSurfaceVariant = Color(0xFF444C63),
    primaryContainer = Color(0xFFC6EEFF), onPrimaryContainer = Color(0xFF001F29), error = Color(0xFFB3261E),
)

@Composable
fun BenderTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
