package com.bender.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/** Thin wrapper over Android's SpeechRecognizer. Must be collected on the main thread. One session per collect. */
class SpeechInput(private val ctx: Context) {

    sealed interface Event {
        data class Partial(val text: String) : Event
        data class Final(val text: String) : Event
        data class Error(val code: Int) : Event
    }

    fun available() = SpeechRecognizer.isRecognitionAvailable(ctx)

    /** [language] e.g. "en-US" / "ha-NG"; null = try on-device language detection (Android 13+), else device default. */
    fun listen(language: String?): Flow<Event> = callbackFlow {
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(error: Int) { trySend(Event.Error(error)); close() }
            override fun onPartialResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isNotBlank()) trySend(Event.Partial(t))
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                trySend(Event.Final(t)); close()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        if (language != null) {
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
        } else if (Build.VERSION.SDK_INT >= 33) {
            i.putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_DETECTION_ALLOWED_LANGUAGES, arrayListOf("en-US", "ha-NG"))
        }
        r.startListening(i)
        awaitClose { r.cancel(); r.destroy() }
    }

    companion object {
        fun errorText(code: Int): String = when (code) {
            SpeechRecognizer.ERROR_AUDIO -> "The microphone isn't available right now."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "I need microphone permission to listen."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                "Speech recognition needs an internet connection for this language."
            SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that. Try again?"
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognition is busy. Try again in a moment."
            12, 13 -> "This language isn't supported by speech recognition on this phone. Try English, or install the language in Google voice settings."
            else -> "Speech recognition failed. Please try again."
        }
    }
}
