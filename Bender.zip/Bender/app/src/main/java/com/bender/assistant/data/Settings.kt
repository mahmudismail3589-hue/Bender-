package com.bender.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.bender.assistant.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("bender_settings")

object Keys {
    val WAKE = booleanPreferencesKey("wake")
    val PHRASE = stringPreferencesKey("phrase")
    val LANG = stringPreferencesKey("lang")          // auto | en | ha
    val VOICE = stringPreferencesKey("voice")
    val RATE = floatPreferencesKey("rate")
    val BACKEND = stringPreferencesKey("backend")
    val MODEL = stringPreferencesKey("model")
    val BACKGROUND = booleanPreferencesKey("background")
    val MEMORY = booleanPreferencesKey("memory")
    val THEME = stringPreferencesKey("theme")        // system | light | dark
    val ONBOARDED = booleanPreferencesKey("onboarded")
    val CONFIRM = booleanPreferencesKey("confirm")
    val CONTINUOUS = booleanPreferencesKey("continuous")
}

data class BenderSettings(
    val wakeWord: Boolean = false,
    val wakePhrase: String = "hey bender",
    val language: String = "auto",
    val voiceName: String = "",
    val speechRate: Float = 1f,
    val backendUrl: String = BuildConfig.DEFAULT_BACKEND_URL,
    val model: String = "",
    val backgroundOn: Boolean = false,
    val memoryOn: Boolean = false,
    val theme: String = "system",
    val onboarded: Boolean = false,
    val confirmActions: Boolean = true,
    val continuous: Boolean = true,
)

class SettingsRepo(private val ctx: Context) {
    val flow: Flow<BenderSettings> = ctx.ds.data.map { p ->
        val d = BenderSettings()
        BenderSettings(
            wakeWord = p[Keys.WAKE] ?: d.wakeWord,
            wakePhrase = p[Keys.PHRASE] ?: d.wakePhrase,
            language = p[Keys.LANG] ?: d.language,
            voiceName = p[Keys.VOICE] ?: d.voiceName,
            speechRate = p[Keys.RATE] ?: d.speechRate,
            backendUrl = p[Keys.BACKEND] ?: d.backendUrl,
            model = p[Keys.MODEL] ?: d.model,
            backgroundOn = p[Keys.BACKGROUND] ?: d.backgroundOn,
            memoryOn = p[Keys.MEMORY] ?: d.memoryOn,
            theme = p[Keys.THEME] ?: d.theme,
            onboarded = p[Keys.ONBOARDED] ?: d.onboarded,
            confirmActions = p[Keys.CONFIRM] ?: d.confirmActions,
            continuous = p[Keys.CONTINUOUS] ?: d.continuous,
        )
    }

    suspend fun now(): BenderSettings = flow.first()
    suspend fun <T> set(key: Preferences.Key<T>, value: T) { ctx.ds.edit { it[key] = value } }
}

/** Encrypted storage for the proxy access token. This is NOT an AI-provider key; that lives only on your server. */
class SecureStore(private val ctx: Context) {
    private val prefs by lazy {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "bender_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }
    fun token(): String? = prefs.getString("app_token", null)
    fun setToken(v: String) { prefs.edit().putString("app_token", v.trim()).apply() }
}
