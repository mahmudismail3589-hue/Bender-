package com.bender.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/** Text-to-speech wrapper. Cancelling the calling coroutine (or calling stop()) interrupts speech immediately. */
class Tts(ctx: Context) {
    enum class Result { Spoken, Fallback, Failed }

    private val ready = CompletableDeferred<Boolean>()
    @Volatile private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status -> ready.complete(status == TextToSpeech.SUCCESS) }
    }

    suspend fun speak(text: String, langTag: String, rate: Float, voice: String?): Result {
        if (!ready.await()) return Result.Failed
        val t = tts ?: return Result.Failed
        var fallback = false
        val r = t.setLanguage(Locale.forLanguageTag(langTag))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.US); fallback = true // e.g. no Hausa voice installed on most phones
        } else if (!voice.isNullOrBlank()) {
            t.voices?.firstOrNull { it.name == voice }?.let { t.voice = it }
        }
        t.setSpeechRate(rate.coerceIn(0.5f, 2f))
        val id = UUID.randomUUID().toString()
        val ok = suspendCancellableCoroutine<Boolean> { cont ->
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (cont.isActive) cont.resume(true) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { if (cont.isActive) cont.resume(false) }
                override fun onStop(utteranceId: String?, interrupted: Boolean) { if (cont.isActive) cont.resume(true) }
            })
            cont.invokeOnCancellation { t.stop() }
            if (t.speak(text.take(3900), TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.ERROR && cont.isActive) cont.resume(false)
        }
        return if (!ok) Result.Failed else if (fallback) Result.Fallback else Result.Spoken
    }

    fun stop() { tts?.stop() }

    suspend fun voiceNames(langTag: String): List<String> {
        if (!ready.await()) return emptyList()
        val lang = langTag.substringBefore('-')
        return tts?.voices.orEmpty().filter { it.locale.language == lang }.map { it.name }.sorted()
    }
}
