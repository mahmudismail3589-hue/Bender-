package com.bender.assistant.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.speech.SpeechRecognizer
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bender.assistant.data.Keys

/** First launch: one optional step at a time. Nothing is requested until you tap the button on that step. */
@Composable
fun OnboardingScreen(vm: MainViewModel, onRequestPerm: (String) -> Unit, onFinish: () -> Unit) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(0) }
    val s by vm.settings.collectAsStateWithLifecycle()
    val last = 6
    val next = { if (step >= last) onFinish() else step++ }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        @Composable fun Step(title: String, body: String, primary: String?, onPrimary: () -> Unit = {}, skip: String = "Skip", extra: @Composable () -> Unit = {}) {
            Text(title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(12.dp))
            Text(body, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            extra()
            if (primary != null) Button(onClick = onPrimary, modifier = Modifier.fillMaxWidth()) { Text(primary) }
            if (skip.isNotEmpty()) TextButton(onClick = { next() }) { Text(skip) }
        }

        when (step) {
            0 -> Step("Welcome to Bender", "Your personal AI assistant.\n\nEnglish and Hausa. A few quick optional steps; you can skip any of them.", "Get started", { next() }, skip = "")
            1 -> Step("Microphone", "Bender needs the microphone to hear you. It listens only when you tap the orb, or if you turn on the wake word.", "Allow microphone",
                { onRequestPerm(Manifest.permission.RECORD_AUDIO) }, "Continue")
            2 -> if (Build.VERSION.SDK_INT >= 33) Step("Notifications", "Used for the background status notification (Talk / Pause / Stop) and reminders.", "Allow notifications",
                { onRequestPerm(Manifest.permission.POST_NOTIFICATIONS) }, "Continue") else LaunchedEffect(Unit) { step++ }
            3 -> {
                val ok = SpeechRecognizer.isRecognitionAvailable(ctx)
                Step("Speech recognition", if (ok) "Speech recognition is available on this phone. Hausa works only if your Google speech services support it; otherwise use English or typing."
                else "Speech recognition isn't available. Install or enable Google speech services.", "Voice input settings",
                    { runCatching { ctx.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) } }, "Continue")
            }
            4 -> Step("Background assistant", "Bender can stay ready behind a visible notification with Talk / Pause / Stop. Android decides how reliably it can run in the background.", "Enable background assistant",
                { vm.set(Keys.BACKGROUND, true) }, "Continue")
            5 -> Step("Optional access", "Contacts let Bender call or message people by name. Notification access lets it read notifications aloud. Both are optional.", null, skip = "Continue",
                extra = {
                    OutlinedButton(onClick = { onRequestPerm(Manifest.permission.READ_CONTACTS) }, modifier = Modifier.fillMaxWidth()) { Text("Allow contacts") }
                    OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Notification access") }
                })
            else -> {
                var token by remember { mutableStateOf(vm.token().orEmpty()) }
                Step("AI brain", "Enter your proxy server address. Without it Bender still handles basic commands offline. API keys stay on your server, never in this app.", null, skip = "Finish", extra = {
                    TextSetting("Backend URL (https://…)", s?.backendUrl.orEmpty()) { vm.set(Keys.BACKEND, it.trim()) }
                    TextSetting("Access token (optional)", token, secret = true) { vm.saveToken(it); token = it }
                    Spacer(Modifier.height(8.dp))
                })
            }
        }
    }
}
