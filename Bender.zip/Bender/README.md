# Bender: Android AI voice assistant (English + Hausa)

Kotlin, Jetpack Compose, MVVM + a shared `AssistantEngine`, Coroutines/StateFlow, Room, DataStore, Retrofit/OkHttp, a microphone foreground service. minSdk 26, targetSdk 34.

> **Build status:** this project was written without access to a Kotlin compiler, Gradle or the Android SDK, so it has **not been compiled yet**. It was checked statically (balanced syntax, manifest/class/resource references). Expect to fix a few small compile errors on first sync; they should be quick.

## Setup
1. Install Android Studio (Koala or newer) with JDK 17. **File > Open** the `Bender` folder. Let Gradle sync (Studio creates the Gradle wrapper jar; only `gradle-wrapper.properties` is shipped).
2. Run the AI proxy (the app never holds a provider key):
   ```
   cd proxy && npm install
   export AI_API_KEY="YOUR_AI_API_KEY"            # stays on the server
   export BENDER_APP_TOKEN="long-random-string"   # shared secret the app sends
   npm start                                      # http://localhost:8787
   ```
   Deploy it behind HTTPS and add rate limiting before real use.
3. In the app: Settings > AI model / API: set Backend URL (`http://10.0.2.2:8787/` on the emulator; HTTPS elsewhere) and the access token. Or set `DEFAULT_BACKEND_URL` in `app/build.gradle.kts`.
4. Run on a **real phone** if possible. Emulators have poor speech recognition and no Hausa voices.
5. Optional: Settings > Default apps > Digital assistant app > Bender, so long-press home or the power button opens Bender listening.

Without a backend, Bender still runs common English/Hausa commands offline (flashlight, open app, call, alarm, time).

## Project layout (`app/src/main/java/com/bender/assistant`)
| Package | Contents |
|---|---|
| `ui` | Compose screens: main (orb, transcript, mic, keyboard), settings, memory, onboarding, theme |
| `engine` | `AssistantEngine`: listen > think > act > speak; shared by UI and service |
| `voice` | `SpeechInput` (SpeechRecognizer), `Tts`, `WakeWordDetector` |
| `ai` | Retrofit contract to your proxy, `Brain` (prompt + JSON parsing, error mapping) |
| `commands` | `BenderAction`, `ActionExecutor`, offline `LocalCommands` (EN+HA), notification listener, reminders |
| `service` | `BenderService` (foreground, microphone type) and `BenderSync` |
| `data` | Room (history, memories), DataStore settings, encrypted token store |

## How it works
- **Foreground:** tap the orb: Listening > Thinking > Speaking. Tap while speaking to interrupt and talk (barge-in). Keyboard input is the second button.
- **Background:** Settings > Background assistant shows a persistent notification with *Talk to Bender / Pause / Stop*. The mic is only used if **Wake word** is also on. Wake word alone runs only while the app is visible.
- **AI actions:** the model returns `{reply, lang, actions[]}`. Phone actions run through public Android APIs.

## What Android does NOT let an ordinary app do (and what Bender does instead)
- **True always-on hotword like Siri/Bixby/"Hey Google".** That uses privileged `HotwordDetectionService`/DSP access. Bender loops short `SpeechRecognizer` sessions only while its foreground service runs. This costs more battery than a real hotword engine, may beep on some devices, and Android/OEM battery managers can stop it. For better detection, plug an offline engine (e.g. Picovoice Porcupine) into `WakeWordDetector`.
- **Starting the mic service from the background / after reboot.** Android 12+ blocks background starts and Android 14+ requires the user to have opened the app. Bender does not restart itself after a reboot or process kill; open the app once to resume.
- **Opening other apps/settings from the background** (Android 10+). Bender posts a tap-to-run notification ("Tap to open WhatsApp"). In the foreground it opens them directly.
- **Silent SMS / silent calls.** SMS opens a pre-filled composer and you press send. Calls open the dialer, or call directly only after you confirm and grant Phone permission.
- **Reading other apps' content, lock-screen control, accessibility tricks.** Not used. Notification reading needs explicit Notification Access, is in-memory only, and is never sent to the AI.
- **Reminders** use inexact alarms and are not restored after a reboot.
- **Hausa:** speech recognition and especially TTS voices depend on Google speech services on the device. Where no Hausa voice exists Bender says so and uses a default voice. Auto-detect uses on-device language detection on Android 13+ only; otherwise pick a language.
- **Live data (weather/news):** the base model has none. Bender opens a web search; add a search tool to your proxy for real answers.

## Privacy and security
- No provider API key in the app. Proxy token stored with `EncryptedSharedPreferences`.
- Cleartext HTTP is blocked except `10.0.2.2`/`localhost` for development; `allowBackup=false`.
- Permissions are requested one at a time, when the feature needs it (onboarding steps are all skippable).
- Memory is off by default; view, delete, or clear everything in Settings. Conversation history is local and clearable.
- The mic is never used silently: it listens only after an orb/notification tap, or while Wake word is on (a visible notification is always shown).

## Voice command examples
"Hey Bender, what time is it" / "open WhatsApp" / "call Ahmed" / "set an alarm for 6 AM" / "turn on the flashlight" / "bude WhatsApp" / "saita min alarm karfe shida na safe" / "kira Ahmad" / "kunna flashlight". Other phrasings, reminders, SMS, translation, writing and coding help go to the AI.

## Troubleshooting
- "Speech recognition isn't available": install/enable Google speech services.
- Wake word does nothing: grant mic permission, enable Wake word, keep the notification visible, exempt Bender from battery optimization.
- "AI brain isn't set up": set Backend URL (and token) in Settings.
