// Minimal Bender AI proxy. Your AI provider key lives ONLY here (environment variable), never in the Android app.
//   export AI_API_KEY="YOUR_AI_API_KEY"   export BENDER_APP_TOKEN="a-long-random-string"   npm i && npm start
// Add rate limiting (e.g. express-rate-limit) and HTTPS (reverse proxy / hosting platform) before real use.
import express from "express";

const app = express();
app.use(express.json({ limit: "256kb" }));

const API_KEY = process.env.AI_API_KEY;            // YOUR_AI_API_KEY
const APP_TOKEN = process.env.BENDER_APP_TOKEN;    // shared secret the app sends as "Bearer <token>"
const DEFAULT_MODEL = process.env.MODEL || "claude-sonnet-5-5";

app.post("/chat", async (req, res) => {
  if (APP_TOKEN && req.get("authorization") !== `Bearer ${APP_TOKEN}`) return res.status(401).json({ error: "unauthorized" });
  if (!API_KEY) return res.status(500).json({ error: "server missing AI_API_KEY" });

  const { system = "", messages = [], model } = req.body || {};
  const msgs = messages.filter((m) => m && typeof m.content === "string").slice(-20);
  while (msgs.length && msgs[0].role !== "user") msgs.shift();   // provider requires a leading user turn
  if (!msgs.length) return res.status(400).json({ error: "no messages" });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: model || DEFAULT_MODEL, max_tokens: 700, system: String(system).slice(0, 8000), messages: msgs }),
    });
    if (!r.ok) return res.status(502).json({ error: await r.text() });
    const j = await r.json();
    res.json({ reply: (j.content || []).filter((b) => b.type === "text").map((b) => b.text).join("") });
  } catch (e) {
    res.status(502).json({ error: String(e) });
  }
});

app.listen(process.env.PORT || 8787, () => console.log("Bender proxy listening"));
